export { WcHomePageView } from './src/WcHomePageView.js';
import '@material/mwc-icon';
import '@material/mwc-textfield';
import '@bbva/wc-theme';
