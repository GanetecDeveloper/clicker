import { LitElement, property, state } from 'lit-element';
import { User } from './domain/User';
import { ExitEvent, ExitEventDetail } from './event/ExitEvent';

export class WcGamePageViewModel extends LitElement {

  // @property({ type: Object }) user!: User;
  @property({ type: String }) name!: string;

  // @property({ type: Object, reflect: true }) set user(newUser: User) {
  //   const oldValue = this._user;
  //   this._user = newUser;
  //   console.log("USER SET", newUser);
  // this.requestUpdate("user", newUser);
  // this.requestUpdate();
  // }
  // get user(): User {
  //   console.log("USER GET", this._user);
  //   return this._user;
  // }
  // protected _user!: User;

  @state() points: number = 0;

  @state() autoClickers: number = 0;

  private autoClickerBaseCost: number = 10;

  private autoClickerTime: number = 100;

  autoClickerCost: number = this.autoClickerBaseCost;

  private timer: ReturnType<typeof setTimeout> | undefined;

  protected _addPoint = (): void => { this.points++ }

  protected _addAutoclicker = (): void => {
    if (this.timer) {
      clearTimeout(this.timer);
    }
    this.timer = setInterval(this._addAutoClickerPoints, this.autoClickerTime);
    this.points -= this.autoClickerCost;
    this.autoClickers++;
    this.autoClickerCost = this.autoClickerBaseCost + this.autoClickerBaseCost * this.autoClickers;
    console.log(this.name)
  }

  protected _addAutoClickerPoints = (): void => { this.points += this.autoClickers }

  protected _exit = (): void => {
    console.log("EXIT !!!");
    const newEvent = new ExitEvent('exitGame', {
      bubbles: true,
      composed: true,
      detail: new ExitEventDetail("itemSelected.data"),
    });
    this.dispatchEvent(newEvent);
  }

  protected isButtonVisible = (): boolean => this.points >= this.autoClickerCost;

  protected isButtonEnable = (): boolean => this.autoClickers >= 1 && this.isButtonVisible();

}
