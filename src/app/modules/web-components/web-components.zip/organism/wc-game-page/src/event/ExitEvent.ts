
export class ExitEvent extends CustomEvent<ExitEventDetail> { }

export class ExitEventDetail {

  private _dataSelected: any;

  constructor(dataSelected: any) {
    this._dataSelected = dataSelected;
  }

  public get dataSelected(): any {
    return this._dataSelected;
  }

}
