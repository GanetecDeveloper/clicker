import { CSSResult } from 'lit-element';
export declare const styles: CSSResult;
//# sourceMappingURL=game-page.css.d.ts.map