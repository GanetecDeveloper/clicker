import { CSSResult } from 'lit-element';
export declare const styles: CSSResult;
//# sourceMappingURL=timesheet.css.d.ts.map