export { WcGamePageView } from './src/WcGamePageView.js';
export { User, IUser } from './src/domain/User.js';
import '@material/mwc-icon';
import '@material/mwc-button';
import '@material/mwc-icon-button';
import '@material/mwc-top-app-bar-fixed';
import '@bbva/wc-login-form';
import '@bbva/wc-theme';
