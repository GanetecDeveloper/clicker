import { CSSResult } from "lit-element";
export declare const rrhhThemeBase: CSSResult;
//# sourceMappingURL=base.css.d.ts.map