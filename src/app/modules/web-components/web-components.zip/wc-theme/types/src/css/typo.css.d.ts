import { CSSResult } from "lit-element";
export declare const rrhhThemeGlobalTypo: CSSResult;
//# sourceMappingURL=typo.css.d.ts.map