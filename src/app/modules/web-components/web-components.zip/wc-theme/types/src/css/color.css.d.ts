import { CSSResult } from "lit-element";
export declare const themeColor: CSSResult;
/**
 * @deprecated
 */
export declare class ColorsTheme {
    /**
     * @deprecated
     */
    static rrhhThemePrimaryColor: CSSResult;
    /**
     * @deprecated
     */
    static rrhhThemeSecondaryColor: CSSResult;
}
//# sourceMappingURL=color.css.d.ts.map