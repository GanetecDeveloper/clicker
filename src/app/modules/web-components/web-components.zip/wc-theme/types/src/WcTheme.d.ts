import { CSSResultArray } from 'lit-element';
export declare class WcTheme {
    getStyles: () => CSSResultArray;
    loadHeadStyles: () => void;
}
//# sourceMappingURL=WcTheme.d.ts.map