import { CSSResult } from "lit-element";
export declare const rrhhThemeGlobalShadow: CSSResult;
//# sourceMappingURL=shadow.css.d.ts.map