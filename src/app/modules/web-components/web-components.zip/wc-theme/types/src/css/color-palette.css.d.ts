import { CSSResult } from "lit-element";
export declare const themeColor: CSSResult;
//# sourceMappingURL=color-palette.css.d.ts.map