export { rrhhThemeBase } from './src/css/base.css';
export { ColorsTheme } from './src/css/color.css';
export { rrhhThemeGlobalShadow } from './src/css/shadow.css';
export { rrhhThemeGlobalTypo } from './src/css/typo.css';
export { WcTheme } from './src/WcTheme';
//# sourceMappingURL=index.d.ts.map