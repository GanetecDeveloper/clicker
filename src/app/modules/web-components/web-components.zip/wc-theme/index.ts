export { WcTheme } from './src/WcTheme';
import { WcTheme } from './src/WcTheme';
new WcTheme().loadHeadStyles();
